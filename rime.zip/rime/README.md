# RIME 

A Pen created on CodePen.io. Original URL: [https://codepen.io/bm3lo/pen/RNbggqw](https://codepen.io/bm3lo/pen/RNbggqw).

